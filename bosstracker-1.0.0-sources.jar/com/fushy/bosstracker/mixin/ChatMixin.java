package com.fushy.bosstracker.mixin;

import com.fushy.bosstracker.BossTimerManager;
import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public class ChatMixin {

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"))
    private void onChatMessage(class_2561 message, CallbackInfo ci) {
        String raw = message.getString();
        // Cherche uniquement le pattern "-= Classement X =-"
        BossTimerManager.handleChatMessage(raw);
    }
}
